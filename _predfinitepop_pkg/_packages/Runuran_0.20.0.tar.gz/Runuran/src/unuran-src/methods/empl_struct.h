/* Copyright (c) 2000-2012 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_empl_par {
  int dummy;
};
struct unur_empl_gen {
  double *observ;      
  int     n_observ;    
};
