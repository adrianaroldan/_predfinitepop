/* Copyright (c) 2000-2012 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

UNUR_PAR *unur_auto_new( const UNUR_DISTR *distribution );
int unur_auto_set_logss( UNUR_PAR *parameters, int logss );
