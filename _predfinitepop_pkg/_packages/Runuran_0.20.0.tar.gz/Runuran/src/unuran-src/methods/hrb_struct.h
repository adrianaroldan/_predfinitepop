/* Copyright (c) 2000-2012 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_hrb_par { 
  double upper_bound;                 
};
struct unur_hrb_gen { 
  double upper_bound;                 
  double left_border;                 
};
