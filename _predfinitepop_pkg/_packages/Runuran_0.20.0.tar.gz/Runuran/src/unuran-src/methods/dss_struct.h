/* Copyright (c) 2000-2012 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_dss_par { 
  int dummy;
};
struct unur_dss_gen { 
  int dummy;
};
