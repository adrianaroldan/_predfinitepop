/* Copyright (c) 2000-2012 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_auto_par {
  int logss;                       
};
struct unur_auto_gen {
  int dummy;                       
};
