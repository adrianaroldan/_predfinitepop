/* Copyright (c) 2000-2012 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

struct unur_dsrou_par { 
  double  Fmode;             
};
struct unur_dsrou_gen { 
  double  ul, ur;            
  double  al, ar;            
  double  Fmode;             
};
