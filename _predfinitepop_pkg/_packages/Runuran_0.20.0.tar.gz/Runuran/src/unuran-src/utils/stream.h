/* Copyright (c) 2000-2012 Wolfgang Hoermann and Josef Leydold */
/* Department of Statistics and Mathematics, WU Wien, Austria  */

FILE *unur_set_stream( FILE *new_stream );
FILE *unur_get_stream( void );
